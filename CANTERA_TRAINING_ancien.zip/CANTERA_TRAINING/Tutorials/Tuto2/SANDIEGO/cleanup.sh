#!/bin/sh

# to execute: sh cleanup.sh 

\rm *.csv
\rm *.xml
\rm *.png
